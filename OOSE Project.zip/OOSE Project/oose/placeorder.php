<?php

	$orderid = $_POST['orderid'];
	$typeofgoods = $_POST['typeofgoods'];
	$orderdate = $_POST['orderdate'];
	$withdrawdate = $_POST['withdrawdate'];
	$valueofgoods = $_POST['valueofgoods'];

	echo $typeofgoods;

	$myServer = "localhost";
	$myUser = "root";
	$myPass = "password"; 
	$myDB = "login"; 
		
	$dbhandle = mysql_connect($myServer, $myUser, $myPass)
	  or die("Couldn't connect to SQL Server on $myServer"); 
	
	$selected = mysql_select_db($myDB, $dbhandle)
	  or die("Couldn't open database $myDB"); 
	//$query = "INSERT INTO order VALUES('$orderid','$typeofgoods','$orderdate','$withdrawdate','$valueofgoods ');";
	 $query = "INSERT INTO `login`.`order` (`orderid`, `typeofgoods`, `orderdate`, `withdrawdate`, `valueofgoods`) VALUES ('$orderid', '$typeofgoods', '$orderdate', '$withdrawdate', '$valueofgoods')";
	
	 mysql_query($query) or die(mysql_error());
	
	header("location:placeorder1.html");
	

?>