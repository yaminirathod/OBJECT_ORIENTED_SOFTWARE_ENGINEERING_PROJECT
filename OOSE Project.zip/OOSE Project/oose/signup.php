<?php

	$customername = $_POST['customername'];
	$email = $_POST['emailid'];
	$address = $_POST['address'];
	$contact = $_POST['contact'];
	$password = $_POST['password'];

	$myServer = "localhost";
	$myUser = "root";
	$myPass = "password"; 
	$myDB = "login"; 
		
	$dbhandle = mysql_connect($myServer, $myUser, $myPass)
	  or die("Couldn't connect to SQL Server on $myServer"); 
	
	$selected = mysql_select_db($myDB, $dbhandle)
	  or die("Couldn't open database $myDB"); 
	$query = "INSERT INTO customer VALUES('$customername','$password','$address','$email','$contact ');";
	 mysql_query($query) or die(mysql_error());
	 
	header("location:afterlogin.html");

?>