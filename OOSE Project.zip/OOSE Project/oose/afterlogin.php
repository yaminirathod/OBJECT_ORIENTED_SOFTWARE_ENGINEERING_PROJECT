<?php
session_start();
if(!isset($_SESSION['customername'])){
	header("location: ./main.html");
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Design by http://www.bluewebtemplates.com
Released for free under a Creative Commons Attribution 3.0 License
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Template</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style1.css" rel="stylesheet" type="text/css" />
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section -->
<script type="text/javascript" src="js1/cufon-yui.js"></script>
<script type="text/javascript" src="js1/arial.js"></script>
<script type="text/javascript" src="js1/cuf_run.js"></script>
<!-- CuFon ends -->
</head>
<body>
<div class="main">

  <div class="header">
    <div class="header_resize">
      <div class="logo"><h1><a href="index.html">Inventory Management System<br /><small>Your goods, Our responsibility</small></a></h1></div>
      
	  <div class="clr"></div>
      
      <div class="clr"></div>
    </div>
  </div>

  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>Welcome !!!</span></h2>
          <p>
		  <table>
		  <tr><td><td><td><td><td><td><td><td><td><td><td><td><td><td>
		  <td><h3><a href="placeorder.html">Place Order</a></h3><td><td><td>
		  <td><h3><a href="trackorder.html">Track Order</a></h3>
		  </tr><br>
		  <tr><td><td><td><td><td><td><td><td><td><td><td><td><td><td>
		  <td><a href="placeorder.html"><img src="15.jpg" width="75" height="75" alt="white" /></a><td><td><td>
		  <td><a href="trackorder.html"><img src="16.jpg" width="75" height="75" alt="white" /></a>
		  </tr>
		  </table>
		  </p>
          
          <p class="lbg">March 26, 2014</p><br>
		  <p class="lbg"><a href="logout.php">Logout</a></p>
        </div>
        
      </div>
      <div class="sidebar">
        <div class="gadget">
          <h2 class="star"><span>Menu</span></h2>
          <ul class="sb_menu">
            <li><a href="main.html">Home</a></li>
			<li><a href="aboutus.html">About Us</a></li>
            <li><a href="contactus.html">Contact Us</a></li>
            <li><a href="faq.html">FAQ</a></li>
        </ul>
        </div>
        
      </div>
      <div class="clr"></div>
    </div>
  </div>

  
  <div class="footer">
    <div class="footer_resize">
      <p class="lf">&copy; Copyright MPY. Designed by Mansi, Palak and Yamini.</p>
      <ul class="fmenu">
        <li><a href="main.html">Home</a></li>
        <li class="active"><a href="login.html">LogIn</a></li>
        <li><a href="aboutus.html">About Us</a></li>
        <li><a href="contactus.html">Contact Us</a></li>
		<li><a href="faq.html">FAQ</a></li>
      </ul>
      <div class="clr"></div>
    </div>
  </div>
</div>
</body>
</html>
