<?php

$orderid = $_POST['orderid'];


$myServer = "localhost";
$myUser = "root";
$myPass = "password"; 
$myDB = "login"; 
	
$dbhandle = mysql_connect($myServer, $myUser, $myPass)
  or die("Couldn't connect to SQL Server on $myServer"); 

$selected = mysql_select_db($myDB, $dbhandle)
  or die("Couldn't open database $myDB"); 

//declare the SQL statement that will query the database
$query = "SELECT * FROM  `order` WHERE  `orderid` =  '$orderid'";

//echo $query;

//execute the SQL query and return records
$result = mysql_query($query) or die(mysql_error());
$count=mysql_num_rows($result);
echo $count;
if($count==1)
{
 $info = mysql_fetch_array( $result );
 //header("location:trackorder1.html");
}
else
{
 header("location:trackorder2.html");
}

mysql_close($dbhandle);

?>