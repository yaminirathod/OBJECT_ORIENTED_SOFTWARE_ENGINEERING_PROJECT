<?php

session_start();

$customername =  $_POST['customername'];
$password = $_POST['password'];

$myServer = "localhost";
$myUser = "root";
$myPass = "password"; 
$myDB = "login"; 
	
$dbhandle = mysql_connect($myServer, $myUser, $myPass)
  or die("Couldn't connect to SQL Server on $myServer"); 

$selected = mysql_select_db($myDB, $dbhandle)
  or die("Couldn't open database $myDB"); 

//declare the SQL statement that will query the database
$query = "SELECT * FROM  customer  WHERE customername='$customername' AND password='$password'";

//echo $query;

//execute the SQL query and return records
$result = mysql_query($query);
$count=mysql_num_rows($result);

if($count==1)
{
 $info = mysql_fetch_array( $result );
 
 $_SESSION['customername'] = $info['customername'];
 $_SESSION['email'] = $info['emailid'];
 
 header("location:afterlogin.php");
}
else
{
	header("location:login1.html");
}

mysql_close($dbhandle);

?>